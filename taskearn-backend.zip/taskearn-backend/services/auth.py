from datetime import datetime, timedelta, timezone
from typing import Optional
import secrets
import random
import string

from jose import JWTError, jwt
from passlib.context import CryptContext
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, and_
from fastapi import HTTPException, status

from config import settings
from models.user import User, OTPRecord

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")


# ─── Passwords ───────────────────────────────────────────────────────────────

def hash_password(password: str) -> str:
    return pwd_context.hash(password)


def verify_password(plain: str, hashed: str) -> bool:
    return pwd_context.verify(plain, hashed)


# ─── JWT ─────────────────────────────────────────────────────────────────────

def create_access_token(data: dict, expires_delta: Optional[timedelta] = None) -> str:
    to_encode = data.copy()
    expire = datetime.now(timezone.utc) + (
        expires_delta or timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES)
    )
    to_encode.update({"exp": expire})
    return jwt.encode(to_encode, settings.SECRET_KEY, algorithm=settings.ALGORITHM)


def decode_token(token: str) -> dict:
    try:
        return jwt.decode(token, settings.SECRET_KEY, algorithms=[settings.ALGORITHM])
    except JWTError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid or expired token",
            headers={"WWW-Authenticate": "Bearer"},
        )


# ─── OTP ─────────────────────────────────────────────────────────────────────

def generate_otp() -> str:
    """Generate a 6-digit numeric OTP."""
    return "".join(random.choices(string.digits, k=6))


async def create_otp(db: AsyncSession, email: str, purpose: str) -> str:
    """
    Generate OTP, store its hash in the DB, return the plain code.
    The plain code is returned to the API caller so the FRONTEND
    can send it via EmailJS (no SMTP needed on the backend).
    """
    otp_code = generate_otp()
    otp_hash = pwd_context.hash(otp_code)
    expires_at = datetime.now(timezone.utc) + timedelta(minutes=settings.OTP_EXPIRE_MINUTES)

    # Invalidate any previous OTPs for this email+purpose
    existing = await db.execute(
        select(OTPRecord).where(
            and_(OTPRecord.email == email, OTPRecord.purpose == purpose, OTPRecord.is_used == False)
        )
    )
    for old in existing.scalars().all():
        old.is_used = True

    record = OTPRecord(
        email=email,
        otp_hash=otp_hash,
        purpose=purpose,
        expires_at=expires_at,
    )
    db.add(record)
    await db.flush()

    return otp_code


async def verify_otp(db: AsyncSession, email: str, otp_code: str, purpose: str) -> bool:
    """Verify OTP and mark it used. Returns True on success."""
    now = datetime.now(timezone.utc)
    result = await db.execute(
        select(OTPRecord).where(
            and_(
                OTPRecord.email == email,
                OTPRecord.purpose == purpose,
                OTPRecord.is_used == False,
                OTPRecord.expires_at > now,
            )
        ).order_by(OTPRecord.created_at.desc())
    )
    record: Optional[OTPRecord] = result.scalar_one_or_none()

    if not record:
        return False

    record.attempts += 1
    if record.attempts > 5:
        raise HTTPException(status_code=429, detail="Too many OTP attempts. Request a new one.")

    if not pwd_context.verify(otp_code, record.otp_hash):
        await db.flush()
        return False

    record.is_used = True
    await db.flush()
    return True


# ─── Age check ───────────────────────────────────────────────────────────────

def check_minimum_age(dob: datetime, minimum_years: int = 16) -> bool:
    today = datetime.now(timezone.utc).date()
    age = today.year - dob.year - ((today.month, today.day) < (dob.month, dob.day))
    return age >= minimum_years
