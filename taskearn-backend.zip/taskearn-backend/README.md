# TaskEarn Backend API

FastAPI + PostgreSQL backend for TaskEarn — India's task marketplace platform.

## Tech Stack
- **Framework**: FastAPI (async)
- **Database**: PostgreSQL via SQLAlchemy (async)
- **Auth**: JWT (python-jose) + bcrypt
- **Payments**: Razorpay
- **OTP**: Server-generated → sent by frontend via EmailJS
- **Deploy**: Railway

---

## Project Structure

```
taskearn-backend/
├── main.py                  # FastAPI app & startup
├── config.py                # Settings (env vars)
├── database.py              # Async SQLAlchemy engine
├── requirements.txt
├── Procfile                 # Railway start command
├── railway.toml
├── .env.example             # Copy to .env and fill in
├── api-client.js            # Drop into your frontend (replaces old api-client.js)
│
├── models/
│   ├── user.py              # User, OTPRecord
│   ├── task.py              # Task
│   └── wallet.py            # Wallet, Transaction
│
├── routers/
│   ├── auth.py              # /api/auth/*
│   ├── tasks.py             # /api/tasks/*
│   ├── wallet.py            # /api/wallet/*
│   └── payments.py          # /api/payments/*
│
├── services/
│   ├── auth.py              # JWT, password, OTP logic
│   ├── pricing.py           # Service charge calculator
│   └── wallet.py            # Credit/debit wallet
│
└── middleware/
    └── auth_middleware.py   # get_current_user dependency
```

---

## Local Setup

### 1. Clone & install

```bash
cd taskearn-backend
python -m venv venv
source venv/bin/activate          # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

### 2. Configure environment

```bash
cp .env.example .env
# Edit .env with your values
```

**Minimum required vars:**
```
DATABASE_URL=postgresql+asyncpg://user:pass@localhost:5432/taskearn
SECRET_KEY=any-long-random-string
OTP_SECRET_KEY=another-random-string
RAZORPAY_KEY_ID=rzp_test_xxxxx
RAZORPAY_KEY_SECRET=xxxxx
```

### 3. Create PostgreSQL database

```bash
psql -U postgres -c "CREATE DATABASE taskearn;"
```

### 4. Run

```bash
uvicorn main:app --reload
```

API docs: http://localhost:8000/docs

---

## Deploy to Railway

### 1. Create Railway project
```bash
npm install -g @railway/cli
railway login
railway init
```

### 2. Add PostgreSQL plugin
In Railway dashboard → Add Plugin → PostgreSQL  
Copy the `DATABASE_URL` it gives you.

### 3. Set environment variables in Railway dashboard

```
DATABASE_URL          = <from Railway PostgreSQL plugin>
SECRET_KEY            = <generate with: python -c "import secrets; print(secrets.token_hex(32))">
OTP_SECRET_KEY        = <another secrets.token_hex(32)>
RAZORPAY_KEY_ID       = rzp_live_xxxxxx
RAZORPAY_KEY_SECRET   = xxxxxx
RAZORPAY_WEBHOOK_SECRET = xxxxxx
FRONTEND_URL          = https://your-frontend.netlify.app
ENVIRONMENT           = production
```

### 4. Deploy

```bash
railway up
```

Your API will be live at `https://taskearn.up.railway.app`

---

## API Endpoints

### Auth  `/api/auth`
| Method | Path | Auth | Description |
|--------|------|------|-------------|
| POST | `/signup` | ❌ | Register (16+ only) |
| POST | `/login` | ❌ | Login, returns JWT |
| GET | `/me` | ✅ | Get current user |
| PATCH | `/me` | ✅ | Update profile |
| POST | `/otp/generate` | ❌ | Generate OTP (returned for EmailJS) |
| POST | `/otp/verify` | ❌ | Verify OTP code |
| POST | `/password/reset` | ❌ | Reset password with OTP |
| POST | `/find-account` | ❌ | Check if email exists (for forgot password) |

### Tasks  `/api/tasks`
| Method | Path | Auth | Description |
|--------|------|------|-------------|
| POST | `/` | ✅ | Create task |
| GET | `/` | ❌ | List open tasks (with filters) |
| GET | `/my` | ✅ | My posted/accepted tasks |
| GET | `/{id}` | ❌ | Get single task |
| PATCH | `/{id}` | ✅ | Edit task (only poster, only open) |
| DELETE | `/{id}` | ✅ | Delete task |
| POST | `/{id}/accept` | ✅ | Accept task as tasker |
| POST | `/{id}/complete` | ✅ | Mark complete (poster) + credits tasker |
| POST | `/{id}/cancel` | ✅ | Cancel task |
| POST | `/{id}/rate` | ✅ | Rate after completion |

### Wallet  `/api/wallet`
| Method | Path | Auth | Description |
|--------|------|------|-------------|
| GET | `/` | ✅ | Get balance + recent transactions |
| GET | `/transactions` | ✅ | Full transaction history |
| PATCH | `/bank-details` | ✅ | Save bank/UPI details |
| POST | `/withdraw` | ✅ | Request withdrawal |

### Payments  `/api/payments`
| Method | Path | Auth | Description |
|--------|------|------|-------------|
| POST | `/create-order` | ✅ | Create Razorpay order |
| POST | `/verify` | ✅ | Verify payment signature |
| POST | `/webhook` | ❌ | Razorpay webhook receiver |
| GET | `/key` | ❌ | Get public Razorpay key |

---

## OTP Flow (EmailJS integration)

The backend generates OTPs and returns the plain code to the frontend.
The frontend sends it via EmailJS. No SMTP config needed on the server.

```javascript
// In your frontend forgot-password flow:
const { otp_code } = await TaskEarnAPI.Auth.generateOTP(email, 'password_reset');

// Send via EmailJS
await emailjs.send(SERVICE_ID, TEMPLATE_ID, {
  to_email: email,
  otp_code: otp_code,
  app_name: 'TaskEarn'
}, PUBLIC_KEY);

// Later, verify:
await TaskEarnAPI.Auth.verifyOTP(email, userEnteredCode, 'password_reset');

// Or use the all-in-one helper:
await TaskEarnAPI.OTPFlow.sendOTP(email, 'password_reset', SERVICE_ID, TEMPLATE_ID, PUBLIC_KEY);
```

---

## Frontend Integration

1. Replace your old `api-client.js` with the new `api-client.js` from this folder
2. All API calls use `window.TaskEarnAPI`:

```javascript
// Login
const { user } = await TaskEarnAPI.Auth.login(email, password);

// Post a task
const task = await TaskEarnAPI.Tasks.create({
  title: "Need help with laundry",
  category: "laundry",
  description: "3 bags of clothes...",
  location_address: "Koramangala, Bangalore",
  scheduled_at: "2026-03-10T10:00:00Z",
  budget: 300
});

// Pay for the task (opens Razorpay)
await TaskEarnAPI.Payments.openCheckout(task.id, {
  onSuccess: (result) => showToast("Payment successful!"),
  onFailure: (err) => showToast("Payment failed: " + err.message),
});

// Get wallet balance
const wallet = await TaskEarnAPI.Wallet.get();
console.log(wallet.balance);
```

---

## Razorpay Webhook Setup

In Razorpay Dashboard → Webhooks → Add:
- URL: `https://taskearn.up.railway.app/api/payments/webhook`
- Events: `payment.captured`, `payment.failed`
- Set the `RAZORPAY_WEBHOOK_SECRET` in your env to match

---

## Service Charge Tiers

Matches frontend display exactly:

| Budget | Tier | Charge |
|--------|------|--------|
| ₹0–₹99 | Quick | ₹30 |
| ₹100–₹299 | Medium | ₹50 |
| ₹300–₹599 | Skilled | ₹65 |
| ₹600–₹999 | Expert | ₹75 |
| ₹1000+ | Professional | ₹95 |
