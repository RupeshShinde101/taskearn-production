from fastapi import APIRouter, Depends, HTTPException, status, BackgroundTasks
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from pydantic import BaseModel, EmailStr, field_validator
from datetime import datetime, timezone
from typing import Optional
import uuid

from database import get_db
from models.user import User
from models.wallet import Wallet
from services.auth import (
    hash_password, verify_password, create_access_token,
    create_otp, verify_otp, check_minimum_age
)
from middleware.auth_middleware import get_current_user

router = APIRouter(prefix="/auth", tags=["Authentication"])


# ─── Schemas ─────────────────────────────────────────────────────────────────

class SignupRequest(BaseModel):
    first_name: str
    last_name: str
    email: EmailStr
    phone: str
    password: str
    date_of_birth: datetime

    @field_validator("password")
    @classmethod
    def password_strength(cls, v):
        if len(v) < 6:
            raise ValueError("Password must be at least 6 characters")
        return v


class LoginRequest(BaseModel):
    email: EmailStr
    password: str


class OTPRequest(BaseModel):
    email: EmailStr
    purpose: str  # 'password_reset' | 'email_verify'


class OTPVerifyRequest(BaseModel):
    email: EmailStr
    otp_code: str
    purpose: str


class ResetPasswordRequest(BaseModel):
    email: EmailStr
    otp_code: str
    new_password: str


class UpdateProfileRequest(BaseModel):
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    phone: Optional[str] = None
    city: Optional[str] = None
    bio: Optional[str] = None


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: dict


# ─── Helpers ─────────────────────────────────────────────────────────────────

def user_to_dict(user: User) -> dict:
    return {
        "id": str(user.id),
        "first_name": user.first_name,
        "last_name": user.last_name,
        "email": user.email,
        "phone": user.phone,
        "city": user.city,
        "bio": user.bio,
        "is_verified": user.is_verified,
        "avg_rating_as_tasker": float(user.avg_rating_as_tasker or 0),
        "avg_rating_as_poster": float(user.avg_rating_as_poster or 0),
        "created_at": user.created_at.isoformat() if user.created_at else None,
    }


# ─── Routes ──────────────────────────────────────────────────────────────────

@router.post("/signup", response_model=TokenResponse, status_code=201)
async def signup(body: SignupRequest, db: AsyncSession = Depends(get_db)):
    # Age check (16+)
    if not check_minimum_age(body.date_of_birth):
        raise HTTPException(status_code=400, detail="You must be at least 16 years old to join TaskEarn")

    # Check duplicates
    existing = await db.execute(select(User).where(User.email == body.email))
    if existing.scalar_one_or_none():
        raise HTTPException(status_code=409, detail="Email already registered")

    user = User(
        first_name=body.first_name.strip(),
        last_name=body.last_name.strip(),
        email=body.email.lower(),
        phone=body.phone,
        date_of_birth=body.date_of_birth,
        password_hash=hash_password(body.password),
    )
    db.add(user)
    await db.flush()

    # Auto-create wallet
    wallet = Wallet(user_id=user.id)
    db.add(wallet)
    await db.flush()

    token = create_access_token({"sub": str(user.id)})
    return {"access_token": token, "token_type": "bearer", "user": user_to_dict(user)}


@router.post("/login", response_model=TokenResponse)
async def login(body: LoginRequest, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(User).where(User.email == body.email.lower()))
    user = result.scalar_one_or_none()

    if not user or not verify_password(body.password, user.password_hash):
        raise HTTPException(status_code=401, detail="Invalid email or password")

    if not user.is_active:
        raise HTTPException(status_code=403, detail="Account deactivated. Contact support.")

    token = create_access_token({"sub": str(user.id)})
    return {"access_token": token, "token_type": "bearer", "user": user_to_dict(user)}


@router.post("/otp/generate")
async def generate_otp_endpoint(body: OTPRequest, db: AsyncSession = Depends(get_db)):
    """
    Generate OTP server-side. Returns the plain OTP code to the frontend.
    The frontend then sends it via EmailJS. This keeps SMTP off the backend
    while the secret remains server-side.
    """
    if body.purpose not in ("password_reset", "email_verify"):
        raise HTTPException(status_code=400, detail="Invalid OTP purpose")

    # For password_reset: check user exists
    if body.purpose == "password_reset":
        result = await db.execute(select(User).where(User.email == body.email.lower()))
        if not result.scalar_one_or_none():
            # Return success even if not found (security - don't leak emails)
            return {"message": "If this email is registered, an OTP has been prepared", "otp_code": None}

    otp_code = await create_otp(db, body.email.lower(), body.purpose)

    # Return OTP to frontend for EmailJS delivery
    return {
        "message": "OTP generated. Send it via EmailJS from the frontend.",
        "otp_code": otp_code,          # frontend uses this to send the email
        "expires_in_minutes": 10,
    }


@router.post("/otp/verify")
async def verify_otp_endpoint(body: OTPVerifyRequest, db: AsyncSession = Depends(get_db)):
    valid = await verify_otp(db, body.email.lower(), body.otp_code, body.purpose)
    if not valid:
        raise HTTPException(status_code=400, detail="Invalid or expired OTP")
    return {"message": "OTP verified successfully", "verified": True}


@router.post("/password/reset")
async def reset_password(body: ResetPasswordRequest, db: AsyncSession = Depends(get_db)):
    if len(body.new_password) < 6:
        raise HTTPException(status_code=400, detail="Password must be at least 6 characters")

    # Verify OTP (consumes it)
    valid = await verify_otp(db, body.email.lower(), body.otp_code, "password_reset")
    if not valid:
        raise HTTPException(status_code=400, detail="Invalid or expired OTP")

    result = await db.execute(select(User).where(User.email == body.email.lower()))
    user = result.scalar_one_or_none()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    user.password_hash = hash_password(body.new_password)
    await db.flush()
    return {"message": "Password reset successfully. You can now log in."}


@router.get("/me")
async def get_me(current_user: User = Depends(get_current_user)):
    return user_to_dict(current_user)


@router.patch("/me")
async def update_profile(
    body: UpdateProfileRequest,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    if body.first_name:
        current_user.first_name = body.first_name.strip()
    if body.last_name:
        current_user.last_name = body.last_name.strip()
    if body.phone:
        current_user.phone = body.phone
    if body.city is not None:
        current_user.city = body.city
    if body.bio is not None:
        current_user.bio = body.bio

    await db.flush()
    return user_to_dict(current_user)


@router.post("/find-account")
async def find_account(email: str, db: AsyncSession = Depends(get_db)):
    """Used by forgot-password flow to check if account exists and return masked info."""
    result = await db.execute(select(User).where(User.email == email.lower()))
    user = result.scalar_one_or_none()

    if not user:
        return {"found": False}

    # Mask email for display: j***@gmail.com
    parts = user.email.split("@")
    masked = parts[0][0] + "***@" + parts[1]

    return {
        "found": True,
        "masked_email": masked,
        "name": user.first_name,
    }
