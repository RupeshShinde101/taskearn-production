import hmac
import hashlib
import json
from decimal import Decimal

import razorpay
from fastapi import APIRouter, Depends, HTTPException, Request, Header
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from pydantic import BaseModel
from uuid import UUID

from config import settings
from database import get_db
from models.task import Task, TaskStatus
from models.user import User
from models.wallet import TransactionPurpose
from services.wallet import debit_wallet, credit_wallet
from middleware.auth_middleware import get_current_user

router = APIRouter(prefix="/payments", tags=["Payments"])

razorpay_client = razorpay.Client(
    auth=(settings.RAZORPAY_KEY_ID, settings.RAZORPAY_KEY_SECRET)
)


# ─── Schemas ─────────────────────────────────────────────────────────────────

class CreateOrderRequest(BaseModel):
    task_id: UUID


class VerifyPaymentRequest(BaseModel):
    task_id: UUID
    razorpay_order_id: str
    razorpay_payment_id: str
    razorpay_signature: str


# ─── Routes ──────────────────────────────────────────────────────────────────

@router.post("/create-order")
async def create_order(
    body: CreateOrderRequest,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """
    Creates a Razorpay order for the task's total_payable amount.
    Called by the frontend before opening the Razorpay checkout.
    """
    result = await db.execute(select(Task).where(Task.id == body.task_id))
    task = result.scalar_one_or_none()

    if not task:
        raise HTTPException(status_code=404, detail="Task not found")
    if task.poster_id != current_user.id:
        raise HTTPException(status_code=403, detail="Not your task")
    if task.payment_status == "paid":
        raise HTTPException(status_code=400, detail="Task already paid for")

    # Razorpay amount is in paise (multiply by 100)
    amount_paise = int(float(task.total_payable) * 100)

    order = razorpay_client.order.create({
        "amount": amount_paise,
        "currency": "INR",
        "receipt": f"task_{str(task.id)[:16]}",
        "notes": {
            "task_id": str(task.id),
            "task_title": task.title,
            "poster_id": str(current_user.id),
        },
    })

    # Save order_id on task
    task.payment_id = order["id"]
    await db.flush()

    return {
        "order_id": order["id"],
        "amount": amount_paise,
        "currency": "INR",
        "key": settings.RAZORPAY_KEY_ID,
        "task_title": task.title,
        "description": f"Payment for: {task.title}",
        "prefill": {
            "name": current_user.full_name,
            "email": current_user.email,
            "contact": current_user.phone or "",
        },
    }


@router.post("/verify")
async def verify_payment(
    body: VerifyPaymentRequest,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """
    Verifies Razorpay signature and marks the task as paid.
    Also debits the poster's wallet for the service charge (platform fee).
    """
    # 1. Verify signature
    expected_signature = hmac.new(
        settings.RAZORPAY_KEY_SECRET.encode(),
        f"{body.razorpay_order_id}|{body.razorpay_payment_id}".encode(),
        hashlib.sha256,
    ).hexdigest()

    if expected_signature != body.razorpay_signature:
        raise HTTPException(status_code=400, detail="Payment signature verification failed")

    # 2. Load task
    result = await db.execute(select(Task).where(Task.id == body.task_id))
    task = result.scalar_one_or_none()

    if not task:
        raise HTTPException(status_code=404, detail="Task not found")
    if task.payment_status == "paid":
        return {"message": "Already processed", "task_id": str(task.id)}

    # 3. Mark paid
    task.payment_status = "paid"
    task.payment_id = body.razorpay_payment_id

    # 4. Record service charge debit (platform fee tracking)
    await debit_wallet(
        db,
        user_id=current_user.id,
        amount=task.service_charge,
        purpose=TransactionPurpose.service_charge,
        task_id=task.id,
        razorpay_payment_id=body.razorpay_payment_id,
        razorpay_order_id=body.razorpay_order_id,
        description=f"Platform fee for task: {task.title}",
    )

    await db.flush()

    return {
        "message": "Payment verified successfully. Task is now live.",
        "task_id": str(task.id),
        "payment_id": body.razorpay_payment_id,
    }


@router.post("/webhook")
async def razorpay_webhook(request: Request, x_razorpay_signature: str = Header(None)):
    """
    Razorpay webhook for async payment confirmation.
    Register this URL in your Razorpay dashboard.
    """
    body_bytes = await request.body()

    if settings.RAZORPAY_WEBHOOK_SECRET:
        expected = hmac.new(
            settings.RAZORPAY_WEBHOOK_SECRET.encode(),
            body_bytes,
            hashlib.sha256,
        ).hexdigest()

        if x_razorpay_signature != expected:
            raise HTTPException(status_code=400, detail="Invalid webhook signature")

    payload = json.loads(body_bytes)
    event = payload.get("event")

    # Handle payment.captured event (optional - you can expand this)
    if event == "payment.captured":
        payment_entity = payload.get("payload", {}).get("payment", {}).get("entity", {})
        order_id = payment_entity.get("order_id")
        payment_id = payment_entity.get("id")
        # You can cross-check and update task status here if needed

    return {"status": "ok"}


@router.get("/key")
async def get_razorpay_key():
    """Returns the public Razorpay key for the frontend."""
    return {"key": settings.RAZORPAY_KEY_ID}
