/**
 * TaskEarn API Client
 * Connects the frontend to the FastAPI backend.
 * Drop this file into your frontend folder and replace the old api-client.js
 */

const API = window.TASKEARN_API_URL || 'http://localhost:5000/api';

// ─── Token helpers ────────────────────────────────────────────────────────────

function getToken() {
  return localStorage.getItem('taskearn_token');
}

function setToken(token) {
  localStorage.setItem('taskearn_token', token);
}

function clearToken() {
  localStorage.removeItem('taskearn_token');
  localStorage.removeItem('taskearn_user');
}

function setUser(user) {
  localStorage.setItem('taskearn_user', JSON.stringify(user));
}

function getUser() {
  try {
    return JSON.parse(localStorage.getItem('taskearn_user'));
  } catch {
    return null;
  }
}

// ─── Base fetch wrapper ───────────────────────────────────────────────────────

async function apiFetch(path, options = {}) {
  const token = getToken();
  const headers = {
    'Content-Type': 'application/json',
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
    ...(options.headers || {}),
  };

  const res = await fetch(`${API}${path}`, {
    ...options,
    headers,
  });

  if (res.status === 204) return null;

  const data = await res.json().catch(() => ({}));

  if (!res.ok) {
    const msg = data.detail || data.message || `API error ${res.status}`;
    throw new Error(typeof msg === 'string' ? msg : JSON.stringify(msg));
  }

  return data;
}

// ─── Auth ─────────────────────────────────────────────────────────────────────

const Auth = {
  async signup(payload) {
    const data = await apiFetch('/auth/signup', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
    setToken(data.access_token);
    setUser(data.user);
    return data;
  },

  async login(email, password) {
    const data = await apiFetch('/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    });
    setToken(data.access_token);
    setUser(data.user);
    return data;
  },

  logout() {
    clearToken();
    window.location.reload();
  },

  async me() {
    return apiFetch('/auth/me');
  },

  async updateProfile(payload) {
    const data = await apiFetch('/auth/me', {
      method: 'PATCH',
      body: JSON.stringify(payload),
    });
    setUser(data);
    return data;
  },

  async findAccount(email) {
    return apiFetch(`/auth/find-account?email=${encodeURIComponent(email)}`);
  },

  /**
   * Generate OTP server-side.
   * Returns { otp_code } — use this to send via EmailJS from the frontend.
   */
  async generateOTP(email, purpose) {
    return apiFetch('/auth/otp/generate', {
      method: 'POST',
      body: JSON.stringify({ email, purpose }),
    });
  },

  async verifyOTP(email, otp_code, purpose) {
    return apiFetch('/auth/otp/verify', {
      method: 'POST',
      body: JSON.stringify({ email, otp_code, purpose }),
    });
  },

  async resetPassword(email, otp_code, new_password) {
    return apiFetch('/auth/password/reset', {
      method: 'POST',
      body: JSON.stringify({ email, otp_code, new_password }),
    });
  },

  isLoggedIn() {
    return !!getToken();
  },
};

// ─── Tasks ────────────────────────────────────────────────────────────────────

const Tasks = {
  async create(payload) {
    return apiFetch('/tasks/', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  async list(filters = {}) {
    const params = new URLSearchParams();
    Object.entries(filters).forEach(([k, v]) => { if (v !== undefined && v !== null) params.set(k, v); });
    return apiFetch(`/tasks/?${params.toString()}`);
  },

  async getById(taskId) {
    return apiFetch(`/tasks/${taskId}`);
  },

  async myTasks(role = 'poster', status = null) {
    const params = new URLSearchParams({ role });
    if (status) params.set('status', status);
    return apiFetch(`/tasks/my?${params.toString()}`);
  },

  async update(taskId, payload) {
    return apiFetch(`/tasks/${taskId}`, {
      method: 'PATCH',
      body: JSON.stringify(payload),
    });
  },

  async delete(taskId) {
    return apiFetch(`/tasks/${taskId}`, { method: 'DELETE' });
  },

  async accept(taskId) {
    return apiFetch(`/tasks/${taskId}/accept`, { method: 'POST' });
  },

  async complete(taskId) {
    return apiFetch(`/tasks/${taskId}/complete`, { method: 'POST' });
  },

  async cancel(taskId) {
    return apiFetch(`/tasks/${taskId}/cancel`, { method: 'POST' });
  },

  async rate(taskId, rating, review = null) {
    return apiFetch(`/tasks/${taskId}/rate`, {
      method: 'POST',
      body: JSON.stringify({ rating, review }),
    });
  },
};

// ─── Wallet ───────────────────────────────────────────────────────────────────

const Wallet = {
  async get() {
    return apiFetch('/wallet/');
  },

  async getTransactions(page = 1, purpose = null) {
    const params = new URLSearchParams({ page });
    if (purpose) params.set('purpose', purpose);
    return apiFetch(`/wallet/transactions?${params.toString()}`);
  },

  async updateBankDetails(payload) {
    return apiFetch('/wallet/bank-details', {
      method: 'PATCH',
      body: JSON.stringify(payload),
    });
  },

  async withdraw(amount, method) {
    return apiFetch('/wallet/withdraw', {
      method: 'POST',
      body: JSON.stringify({ amount, method }),
    });
  },
};

// ─── Payments (Razorpay) ──────────────────────────────────────────────────────

const Payments = {
  async createOrder(taskId) {
    return apiFetch('/payments/create-order', {
      method: 'POST',
      body: JSON.stringify({ task_id: taskId }),
    });
  },

  async verifyPayment(taskId, razorpayOrderId, razorpayPaymentId, razorpaySignature) {
    return apiFetch('/payments/verify', {
      method: 'POST',
      body: JSON.stringify({
        task_id: taskId,
        razorpay_order_id: razorpayOrderId,
        razorpay_payment_id: razorpayPaymentId,
        razorpay_signature: razorpaySignature,
      }),
    });
  },

  /**
   * Full Razorpay checkout flow.
   * Call this after creating a task to collect payment.
   */
  async openCheckout(taskId, { onSuccess, onFailure } = {}) {
    const order = await Payments.createOrder(taskId);

    const options = {
      key: order.key,
      amount: order.amount,
      currency: order.currency,
      name: 'TaskEarn',
      description: order.description,
      order_id: order.order_id,
      prefill: order.prefill,
      theme: { color: '#6366f1' },
      handler: async function (response) {
        try {
          const result = await Payments.verifyPayment(
            taskId,
            response.razorpay_order_id,
            response.razorpay_payment_id,
            response.razorpay_signature,
          );
          if (onSuccess) onSuccess(result);
        } catch (err) {
          if (onFailure) onFailure(err);
        }
      },
    };

    const rzp = new Razorpay(options);
    rzp.on('payment.failed', function (res) {
      if (onFailure) onFailure(new Error(res.error.description));
    });
    rzp.open();
  },
};

// ─── OTP + EmailJS Integration helper ────────────────────────────────────────

/**
 * Full OTP flow:
 *   1. Generate OTP via backend → get plain code
 *   2. Send email via EmailJS using the plain code
 *
 * Usage:
 *   await OTPFlow.sendOTP(email, 'password_reset', emailjsServiceId, emailjsTemplateId, emailjsPublicKey);
 *   await OTPFlow.verify(email, userEnteredCode, 'password_reset');
 */
const OTPFlow = {
  async sendOTP(email, purpose, ejsServiceId, ejsTemplateId, ejsPublicKey) {
    const { otp_code } = await Auth.generateOTP(email, purpose);

    if (!otp_code) {
      // Backend returned null (email not found) — still show success for security
      return true;
    }

    // Send via EmailJS
    await emailjs.send(
      ejsServiceId,
      ejsTemplateId,
      { to_email: email, otp_code, app_name: 'TaskEarn' },
      ejsPublicKey,
    );

    return true;
  },

  async verify(email, code, purpose) {
    const result = await Auth.verifyOTP(email, code, purpose);
    return result.verified;
  },
};

// ─── Export ───────────────────────────────────────────────────────────────────

window.TaskEarnAPI = { Auth, Tasks, Wallet, Payments, OTPFlow, getUser, setUser };
