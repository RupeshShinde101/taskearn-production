from sqlalchemy import Column, String, Numeric, DateTime, ForeignKey, Text, Enum as SAEnum
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
import uuid
import enum

from database import Base


class TransactionType(str, enum.Enum):
    credit = "credit"           # money in (earnings, refunds, deposits)
    debit = "debit"             # money out (withdrawals, payments)


class TransactionStatus(str, enum.Enum):
    pending = "pending"
    completed = "completed"
    failed = "failed"
    refunded = "refunded"


class TransactionPurpose(str, enum.Enum):
    task_payment = "task_payment"       # poster pays for task
    task_earning = "task_earning"       # tasker earns from task
    withdrawal = "withdrawal"           # tasker withdraws to bank
    deposit = "deposit"                 # add money to wallet
    refund = "refund"                   # refund on cancelled task
    service_charge = "service_charge"   # platform fee deducted


class Wallet(Base):
    __tablename__ = "wallets"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id"), unique=True, nullable=False)

    balance = Column(Numeric(12, 2), default=0.00, nullable=False)
    total_earned = Column(Numeric(12, 2), default=0.00)     # lifetime earnings
    total_spent = Column(Numeric(12, 2), default=0.00)      # lifetime spending
    total_withdrawn = Column(Numeric(12, 2), default=0.00)  # lifetime withdrawals

    # Bank details for withdrawal (stored encrypted in production)
    bank_account_number = Column(String(50), nullable=True)
    bank_ifsc = Column(String(20), nullable=True)
    bank_account_name = Column(String(150), nullable=True)
    upi_id = Column(String(100), nullable=True)

    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())

    user = relationship("User", back_populates="wallet")
    transactions = relationship("Transaction", back_populates="wallet", order_by="Transaction.created_at.desc()")


class Transaction(Base):
    __tablename__ = "transactions"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    wallet_id = Column(UUID(as_uuid=True), ForeignKey("wallets.id"), nullable=False)
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=False)

    type = Column(SAEnum(TransactionType), nullable=False)
    status = Column(SAEnum(TransactionStatus), default=TransactionStatus.pending, nullable=False)
    purpose = Column(SAEnum(TransactionPurpose), nullable=False)

    amount = Column(Numeric(12, 2), nullable=False)
    balance_after = Column(Numeric(12, 2), nullable=False)  # snapshot after txn

    # Reference
    task_id = Column(UUID(as_uuid=True), ForeignKey("tasks.id"), nullable=True)
    razorpay_payment_id = Column(String(255), nullable=True)
    razorpay_order_id = Column(String(255), nullable=True)

    description = Column(Text, nullable=True)
    meta = Column(Text, nullable=True)  # JSON string for extra data

    created_at = Column(DateTime(timezone=True), server_default=func.now())

    wallet = relationship("Wallet", back_populates="transactions")
    user = relationship("User", back_populates="transactions")
