from fastapi import APIRouter, Depends, HTTPException, Query, BackgroundTasks
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, and_, or_, func
from sqlalchemy.orm import selectinload
from pydantic import BaseModel
from datetime import datetime, timedelta, timezone
from typing import Optional, List
from uuid import UUID
import math

from database import get_db
from models.task import Task, TaskStatus, TaskCategory
from models.user import User
from models.wallet import TransactionPurpose
from services.pricing import calculate_service_charge
from services.wallet import debit_wallet, credit_wallet
from middleware.auth_middleware import get_current_user

router = APIRouter(prefix="/tasks", tags=["Tasks"])


# ─── Schemas ─────────────────────────────────────────────────────────────────

class CreateTaskRequest(BaseModel):
    title: str
    description: str
    category: str
    location_address: str
    latitude: Optional[float] = None
    longitude: Optional[float] = None
    scheduled_at: datetime
    budget: float


class UpdateTaskRequest(BaseModel):
    title: Optional[str] = None
    description: Optional[str] = None
    category: Optional[str] = None
    location_address: Optional[str] = None
    scheduled_at: Optional[datetime] = None
    budget_increase: Optional[float] = None   # only allowed to increase


class RatingRequest(BaseModel):
    rating: int        # 1–5
    review: Optional[str] = None


# ─── Helpers ─────────────────────────────────────────────────────────────────

def task_to_dict(task: Task, include_poster: bool = True) -> dict:
    d = {
        "id": str(task.id),
        "title": task.title,
        "description": task.description,
        "category": task.category.value if task.category else None,
        "status": task.status.value if task.status else None,
        "location_address": task.location_address,
        "latitude": task.latitude,
        "longitude": task.longitude,
        "budget": float(task.budget),
        "service_charge": float(task.service_charge),
        "total_payable": float(task.total_payable),
        "worker_earns": float(task.worker_earns),
        "scheduled_at": task.scheduled_at.isoformat(),
        "expires_at": task.expires_at.isoformat(),
        "payment_status": task.payment_status,
        "poster_id": str(task.poster_id),
        "tasker_id": str(task.tasker_id) if task.tasker_id else None,
        "created_at": task.created_at.isoformat() if task.created_at else None,
        "accepted_at": task.accepted_at.isoformat() if task.accepted_at else None,
        "completed_at": task.completed_at.isoformat() if task.completed_at else None,
    }
    if include_poster and task.poster:
        d["poster"] = {
            "id": str(task.poster.id),
            "name": task.poster.full_name,
            "avg_rating": float(task.poster.avg_rating_as_poster or 0),
        }
    return d


def haversine_distance(lat1, lon1, lat2, lon2) -> float:
    """Returns distance in km between two lat/lon points."""
    R = 6371
    phi1, phi2 = math.radians(lat1), math.radians(lat2)
    dphi = math.radians(lat2 - lat1)
    dlambda = math.radians(lon2 - lon1)
    a = math.sin(dphi/2)**2 + math.cos(phi1)*math.cos(phi2)*math.sin(dlambda/2)**2
    return 2 * R * math.atan2(math.sqrt(a), math.sqrt(1 - a))


# ─── Routes ──────────────────────────────────────────────────────────────────

@router.post("/", status_code=201)
async def create_task(
    body: CreateTaskRequest,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    if body.budget < 50:
        raise HTTPException(status_code=400, detail="Minimum budget is ₹50")

    pricing = calculate_service_charge(body.budget)

    try:
        category = TaskCategory(body.category)
    except ValueError:
        raise HTTPException(status_code=400, detail=f"Invalid category: {body.category}")

    now = datetime.now(timezone.utc)
    task = Task(
        title=body.title.strip(),
        description=body.description.strip(),
        category=category,
        location_address=body.location_address,
        latitude=body.latitude,
        longitude=body.longitude,
        scheduled_at=body.scheduled_at,
        expires_at=now + timedelta(hours=12),
        budget=pricing["budget"],
        service_charge=pricing["service_charge"],
        total_payable=pricing["total_payable"],
        worker_earns=pricing["worker_earns"],
        poster_id=current_user.id,
        payment_status="pending",
    )
    db.add(task)
    await db.flush()
    return task_to_dict(task)


@router.get("/")
async def list_tasks(
    category: Optional[str] = Query(None),
    status: Optional[str] = Query("open"),
    lat: Optional[float] = Query(None),
    lon: Optional[float] = Query(None),
    radius_km: float = Query(10),
    min_budget: Optional[float] = Query(None),
    max_budget: Optional[float] = Query(None),
    page: int = Query(1, ge=1),
    limit: int = Query(20, le=50),
    db: AsyncSession = Depends(get_db),
):
    """Public endpoint — lists open/non-expired tasks with optional filters."""
    now = datetime.now(timezone.utc)

    conditions = [Task.expires_at > now]  # only non-expired

    if status:
        try:
            conditions.append(Task.status == TaskStatus(status))
        except ValueError:
            pass

    if category and category != "all":
        try:
            conditions.append(Task.category == TaskCategory(category))
        except ValueError:
            pass

    if min_budget is not None:
        conditions.append(Task.budget >= min_budget)
    if max_budget is not None:
        conditions.append(Task.budget <= max_budget)

    query = (
        select(Task)
        .options(selectinload(Task.poster))
        .where(and_(*conditions))
        .order_by(Task.created_at.desc())
    )

    result = await db.execute(query)
    tasks = result.scalars().all()

    # Distance filter (done in Python as PostGIS isn't assumed)
    if lat and lon:
        tasks = [
            t for t in tasks
            if t.latitude and t.longitude
            and haversine_distance(lat, lon, t.latitude, t.longitude) <= radius_km
        ]

    total = len(tasks)
    start = (page - 1) * limit
    paginated = tasks[start: start + limit]

    return {
        "total": total,
        "page": page,
        "limit": limit,
        "tasks": [task_to_dict(t) for t in paginated],
    }


@router.get("/my")
async def get_my_tasks(
    role: str = Query("poster"),   # 'poster' | 'tasker'
    status: Optional[str] = Query(None),
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    conditions = []
    if role == "poster":
        conditions.append(Task.poster_id == current_user.id)
    else:
        conditions.append(Task.tasker_id == current_user.id)

    if status:
        try:
            conditions.append(Task.status == TaskStatus(status))
        except ValueError:
            pass

    result = await db.execute(
        select(Task)
        .options(selectinload(Task.poster), selectinload(Task.tasker))
        .where(and_(*conditions))
        .order_by(Task.created_at.desc())
    )
    tasks = result.scalars().all()
    return [task_to_dict(t) for t in tasks]


@router.get("/{task_id}")
async def get_task(task_id: UUID, db: AsyncSession = Depends(get_db)):
    result = await db.execute(
        select(Task).options(selectinload(Task.poster)).where(Task.id == task_id)
    )
    task = result.scalar_one_or_none()
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")
    return task_to_dict(task)


@router.patch("/{task_id}")
async def update_task(
    task_id: UUID,
    body: UpdateTaskRequest,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(select(Task).where(Task.id == task_id))
    task = result.scalar_one_or_none()

    if not task:
        raise HTTPException(status_code=404, detail="Task not found")
    if task.poster_id != current_user.id:
        raise HTTPException(status_code=403, detail="Not your task")
    if task.status not in (TaskStatus.open,):
        raise HTTPException(status_code=400, detail="Cannot edit a task that is already accepted or completed")

    if body.title:
        task.title = body.title.strip()
    if body.description:
        task.description = body.description.strip()
    if body.location_address:
        task.location_address = body.location_address
    if body.scheduled_at:
        task.scheduled_at = body.scheduled_at
    if body.category:
        try:
            task.category = TaskCategory(body.category)
        except ValueError:
            raise HTTPException(status_code=400, detail="Invalid category")

    # Budget can only increase
    if body.budget_increase and body.budget_increase > 0:
        new_budget = float(task.budget) + body.budget_increase
        pricing = calculate_service_charge(new_budget)
        task.budget = pricing["budget"]
        task.service_charge = pricing["service_charge"]
        task.total_payable = pricing["total_payable"]
        task.worker_earns = pricing["worker_earns"]

    await db.flush()
    return task_to_dict(task)


@router.delete("/{task_id}", status_code=204)
async def delete_task(
    task_id: UUID,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(select(Task).where(Task.id == task_id))
    task = result.scalar_one_or_none()

    if not task:
        raise HTTPException(status_code=404, detail="Task not found")
    if task.poster_id != current_user.id:
        raise HTTPException(status_code=403, detail="Not your task")
    if task.status in (TaskStatus.accepted, TaskStatus.in_progress):
        raise HTTPException(status_code=400, detail="Cannot delete a task that has been accepted")

    await db.delete(task)


@router.post("/{task_id}/accept")
async def accept_task(
    task_id: UUID,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(
        select(Task).options(selectinload(Task.poster)).where(Task.id == task_id)
    )
    task = result.scalar_one_or_none()

    if not task:
        raise HTTPException(status_code=404, detail="Task not found")
    if task.poster_id == current_user.id:
        raise HTTPException(status_code=400, detail="You cannot accept your own task")
    if task.status != TaskStatus.open:
        raise HTTPException(status_code=400, detail="Task is no longer available")
    if datetime.now(timezone.utc) > task.expires_at:
        task.status = TaskStatus.expired
        raise HTTPException(status_code=400, detail="Task has expired")

    task.tasker_id = current_user.id
    task.status = TaskStatus.accepted
    task.accepted_at = datetime.now(timezone.utc)

    await db.flush()
    return {"message": "Task accepted successfully", "task": task_to_dict(task)}


@router.post("/{task_id}/complete")
async def complete_task(
    task_id: UUID,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(select(Task).where(Task.id == task_id))
    task = result.scalar_one_or_none()

    if not task:
        raise HTTPException(status_code=404, detail="Task not found")

    # Only poster marks as complete
    if task.poster_id != current_user.id:
        raise HTTPException(status_code=403, detail="Only the task poster can mark it complete")
    if task.status != TaskStatus.accepted:
        raise HTTPException(status_code=400, detail="Task must be in 'accepted' state to complete")

    task.status = TaskStatus.completed
    task.completed_at = datetime.now(timezone.utc)

    # Credit tasker's wallet
    if task.tasker_id:
        await credit_wallet(
            db,
            user_id=task.tasker_id,
            amount=task.worker_earns,
            purpose=TransactionPurpose.task_earning,
            task_id=task.id,
            description=f"Earned for completing: {task.title}",
        )

    await db.flush()
    return {"message": "Task marked complete. Tasker wallet credited.", "task": task_to_dict(task)}


@router.post("/{task_id}/cancel")
async def cancel_task(
    task_id: UUID,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(select(Task).where(Task.id == task_id))
    task = result.scalar_one_or_none()

    if not task:
        raise HTTPException(status_code=404, detail="Task not found")
    if task.poster_id != current_user.id and task.tasker_id != current_user.id:
        raise HTTPException(status_code=403, detail="Not your task")
    if task.status in (TaskStatus.completed, TaskStatus.cancelled):
        raise HTTPException(status_code=400, detail="Task already completed or cancelled")

    task.status = TaskStatus.cancelled
    await db.flush()
    return {"message": "Task cancelled"}


@router.post("/{task_id}/rate")
async def rate_task(
    task_id: UUID,
    body: RatingRequest,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    if not 1 <= body.rating <= 5:
        raise HTTPException(status_code=400, detail="Rating must be between 1 and 5")

    result = await db.execute(select(Task).where(Task.id == task_id))
    task = result.scalar_one_or_none()

    if not task:
        raise HTTPException(status_code=404, detail="Task not found")
    if task.status != TaskStatus.completed:
        raise HTTPException(status_code=400, detail="Can only rate completed tasks")

    if current_user.id == task.poster_id:
        task.tasker_rating = body.rating
        task.tasker_review = body.review
    elif current_user.id == task.tasker_id:
        task.poster_rating = body.rating
        task.poster_review = body.review
    else:
        raise HTTPException(status_code=403, detail="Not part of this task")

    await db.flush()
    return {"message": "Rating submitted"}
