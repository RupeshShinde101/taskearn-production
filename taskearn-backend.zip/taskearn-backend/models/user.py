from sqlalchemy import Column, String, Boolean, DateTime, Numeric, Integer, Text, Enum as SAEnum
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
import uuid
import enum

from database import Base


class UserRole(str, enum.Enum):
    user = "user"
    admin = "admin"


class User(Base):
    __tablename__ = "users"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    first_name = Column(String(100), nullable=False)
    last_name = Column(String(100), nullable=False)
    email = Column(String(255), unique=True, nullable=False, index=True)
    phone = Column(String(20), unique=True, nullable=True)
    password_hash = Column(String(255), nullable=False)
    date_of_birth = Column(DateTime, nullable=True)
    role = Column(SAEnum(UserRole), default=UserRole.user, nullable=False)

    is_active = Column(Boolean, default=True)
    is_verified = Column(Boolean, default=False)
    profile_picture = Column(Text, nullable=True)
    bio = Column(Text, nullable=True)
    city = Column(String(100), nullable=True)

    # Ratings
    avg_rating_as_poster = Column(Numeric(3, 2), default=0.0)
    avg_rating_as_tasker = Column(Numeric(3, 2), default=0.0)
    total_reviews = Column(Integer, default=0)

    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())

    # Relationships
    wallet = relationship("Wallet", back_populates="user", uselist=False, cascade="all, delete-orphan")
    posted_tasks = relationship("Task", foreign_keys="Task.poster_id", back_populates="poster")
    accepted_tasks = relationship("Task", foreign_keys="Task.tasker_id", back_populates="tasker")
    transactions = relationship("Transaction", back_populates="user")

    @property
    def full_name(self):
        return f"{self.first_name} {self.last_name}"


class OTPRecord(Base):
    """Server-side OTP store; OTP is generated here and the code is returned
    to the frontend which calls EmailJS to send it. This keeps the secret
    server-side while letting EmailJS handle delivery."""
    __tablename__ = "otp_records"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    email = Column(String(255), nullable=False, index=True)
    otp_hash = Column(String(255), nullable=False)   # bcrypt hash of the 6-digit code
    purpose = Column(String(50), nullable=False)      # 'password_reset' | 'email_verify'
    is_used = Column(Boolean, default=False)
    attempts = Column(Integer, default=0)
    expires_at = Column(DateTime(timezone=True), nullable=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
