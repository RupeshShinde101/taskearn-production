from sqlalchemy import (
    Column, String, Text, Numeric, DateTime, Boolean,
    Integer, ForeignKey, Enum as SAEnum, Float
)
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
import uuid
import enum

from database import Base


class TaskStatus(str, enum.Enum):
    open = "open"
    accepted = "accepted"
    in_progress = "in_progress"
    completed = "completed"
    cancelled = "cancelled"
    expired = "expired"


class TaskCategory(str, enum.Enum):
    household = "household"
    delivery = "delivery"
    tutoring = "tutoring"
    transport = "transport"
    vehicle = "vehicle"
    repair = "repair"
    photography = "photography"
    freelance = "freelance"
    waste = "waste"
    cleaning = "cleaning"
    cooking = "cooking"
    petcare = "petcare"
    gardening = "gardening"
    shopping = "shopping"
    eventhelp = "eventhelp"
    moving = "moving"
    techsupport = "techsupport"
    beauty = "beauty"
    laundry = "laundry"
    catering = "catering"
    babysitting = "babysitting"
    eldercare = "eldercare"
    fitness = "fitness"
    painting = "painting"
    electrician = "electrician"
    plumbing = "plumbing"
    carpentry = "carpentry"
    tailoring = "tailoring"
    other = "other"


class Task(Base):
    __tablename__ = "tasks"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)

    # Core fields
    title = Column(String(255), nullable=False)
    description = Column(Text, nullable=False)
    category = Column(SAEnum(TaskCategory), nullable=False)
    status = Column(SAEnum(TaskStatus), default=TaskStatus.open, nullable=False, index=True)

    # Location
    location_address = Column(Text, nullable=False)
    latitude = Column(Float, nullable=True)
    longitude = Column(Float, nullable=True)

    # Pricing
    budget = Column(Numeric(10, 2), nullable=False)          # what poster set
    service_charge = Column(Numeric(10, 2), nullable=False)  # platform fee
    total_payable = Column(Numeric(10, 2), nullable=False)   # budget + service_charge
    worker_earns = Column(Numeric(10, 2), nullable=False)    # what tasker gets

    # Scheduling
    scheduled_at = Column(DateTime(timezone=True), nullable=False)
    expires_at = Column(DateTime(timezone=True), nullable=False)   # posted_at + 12h

    # Relationships
    poster_id = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=False)
    tasker_id = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True)

    poster = relationship("User", foreign_keys=[poster_id], back_populates="posted_tasks")
    tasker = relationship("User", foreign_keys=[tasker_id], back_populates="accepted_tasks")

    # Payment
    payment_id = Column(String(255), nullable=True)     # Razorpay order_id
    payment_status = Column(String(50), default="pending")  # pending | paid | refunded

    # Ratings
    poster_rating = Column(Integer, nullable=True)      # 1-5 stars given by tasker
    tasker_rating = Column(Integer, nullable=True)      # 1-5 stars given by poster
    poster_review = Column(Text, nullable=True)
    tasker_review = Column(Text, nullable=True)

    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
    accepted_at = Column(DateTime(timezone=True), nullable=True)
    completed_at = Column(DateTime(timezone=True), nullable=True)
