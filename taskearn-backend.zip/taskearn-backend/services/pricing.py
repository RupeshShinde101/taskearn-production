from decimal import Decimal


# Service charge tiers matching the frontend display
CHARGE_TIERS = [
    {"label": "Quick",        "min_budget": 0,    "max_budget": 99,   "charge": 30},
    {"label": "Medium",       "min_budget": 100,  "max_budget": 299,  "charge": 50},
    {"label": "Skilled",      "min_budget": 300,  "max_budget": 599,  "charge": 65},
    {"label": "Expert",       "min_budget": 600,  "max_budget": 999,  "charge": 75},
    {"label": "Professional", "min_budget": 1000, "max_budget": 99999,"charge": 95},
]


def calculate_service_charge(budget: float) -> dict:
    """
    Returns pricing breakdown for a given budget.
    Matches the frontend service charge logic exactly.
    """
    for tier in CHARGE_TIERS:
        if tier["min_budget"] <= budget <= tier["max_budget"]:
            service_charge = tier["charge"]
            total_payable = budget + service_charge
            return {
                "budget": Decimal(str(budget)),
                "service_charge": Decimal(str(service_charge)),
                "total_payable": Decimal(str(total_payable)),
                "worker_earns": Decimal(str(budget)),   # tasker gets full budget
                "tier_label": tier["label"],
            }

    # Fallback – shouldn't happen with valid input
    service_charge = 95
    return {
        "budget": Decimal(str(budget)),
        "service_charge": Decimal(str(service_charge)),
        "total_payable": Decimal(str(budget + service_charge)),
        "worker_earns": Decimal(str(budget)),
        "tier_label": "Professional",
    }
