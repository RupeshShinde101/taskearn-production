from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager

from config import settings
from database import init_db

# Import all models so SQLAlchemy registers them before init_db
import models  # noqa: F401

from routers import auth, tasks, wallet, payments


@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup
    print(f"🚀 Starting {settings.APP_NAME} API [{settings.ENVIRONMENT}]")
    await init_db()
    print("✅ Database tables initialized")
    yield
    # Shutdown
    print("👋 Shutting down")


app = FastAPI(
    title="TaskEarn API",
    description="Backend API for TaskEarn — India's task marketplace platform",
    version="1.0.0",
    docs_url="/docs" if settings.ENVIRONMENT == "development" else None,
    redoc_url="/redoc" if settings.ENVIRONMENT == "development" else None,
    lifespan=lifespan,
)

# ─── CORS ────────────────────────────────────────────────────────────────────
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        settings.FRONTEND_URL,
        "http://localhost:3000",
        "http://127.0.0.1:5500",  # Live Server
        "http://localhost:5500",
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ─── Routers ─────────────────────────────────────────────────────────────────
app.include_router(auth.router,     prefix="/api")
app.include_router(tasks.router,    prefix="/api")
app.include_router(wallet.router,   prefix="/api")
app.include_router(payments.router, prefix="/api")


# ─── Health check ────────────────────────────────────────────────────────────
@app.get("/")
async def root():
    return {
        "app": settings.APP_NAME,
        "status": "online",
        "environment": settings.ENVIRONMENT,
        "version": "1.0.0",
    }


@app.get("/health")
async def health():
    return {"status": "ok"}
