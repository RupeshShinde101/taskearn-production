from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from sqlalchemy.orm import selectinload
from pydantic import BaseModel
from typing import Optional, List
from decimal import Decimal
from uuid import UUID

from database import get_db
from models.user import User
from models.wallet import Wallet, Transaction, TransactionPurpose
from services.wallet import get_or_create_wallet, debit_wallet
from middleware.auth_middleware import get_current_user

router = APIRouter(prefix="/wallet", tags=["Wallet"])


# ─── Schemas ─────────────────────────────────────────────────────────────────

class BankDetailsRequest(BaseModel):
    bank_account_number: Optional[str] = None
    bank_ifsc: Optional[str] = None
    bank_account_name: Optional[str] = None
    upi_id: Optional[str] = None


class WithdrawalRequest(BaseModel):
    amount: float
    method: str   # 'bank' | 'upi'


# ─── Helpers ─────────────────────────────────────────────────────────────────

def txn_to_dict(txn: Transaction) -> dict:
    return {
        "id": str(txn.id),
        "type": txn.type.value,
        "status": txn.status.value,
        "purpose": txn.purpose.value,
        "amount": float(txn.amount),
        "balance_after": float(txn.balance_after),
        "description": txn.description,
        "task_id": str(txn.task_id) if txn.task_id else None,
        "razorpay_payment_id": txn.razorpay_payment_id,
        "created_at": txn.created_at.isoformat() if txn.created_at else None,
    }


# ─── Routes ──────────────────────────────────────────────────────────────────

@router.get("/")
async def get_wallet(
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    wallet = await get_or_create_wallet(db, current_user.id)

    result = await db.execute(
        select(Transaction)
        .where(Transaction.wallet_id == wallet.id)
        .order_by(Transaction.created_at.desc())
        .limit(20)
    )
    recent_txns = result.scalars().all()

    return {
        "balance": float(wallet.balance),
        "total_earned": float(wallet.total_earned),
        "total_spent": float(wallet.total_spent),
        "total_withdrawn": float(wallet.total_withdrawn),
        "bank_account_number": wallet.bank_account_number,
        "bank_ifsc": wallet.bank_ifsc,
        "bank_account_name": wallet.bank_account_name,
        "upi_id": wallet.upi_id,
        "recent_transactions": [txn_to_dict(t) for t in recent_txns],
    }


@router.get("/transactions")
async def get_transactions(
    page: int = Query(1, ge=1),
    limit: int = Query(20, le=100),
    purpose: Optional[str] = Query(None),
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    wallet = await get_or_create_wallet(db, current_user.id)

    conditions = [Transaction.wallet_id == wallet.id]
    if purpose:
        try:
            conditions.append(Transaction.purpose == TransactionPurpose(purpose))
        except ValueError:
            pass

    from sqlalchemy import and_
    result = await db.execute(
        select(Transaction)
        .where(and_(*conditions))
        .order_by(Transaction.created_at.desc())
        .offset((page - 1) * limit)
        .limit(limit)
    )
    txns = result.scalars().all()
    return [txn_to_dict(t) for t in txns]


@router.patch("/bank-details")
async def update_bank_details(
    body: BankDetailsRequest,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    wallet = await get_or_create_wallet(db, current_user.id)

    if body.bank_account_number:
        wallet.bank_account_number = body.bank_account_number
    if body.bank_ifsc:
        wallet.bank_ifsc = body.bank_ifsc.upper()
    if body.bank_account_name:
        wallet.bank_account_name = body.bank_account_name
    if body.upi_id is not None:
        wallet.upi_id = body.upi_id

    await db.flush()
    return {"message": "Bank details updated successfully"}


@router.post("/withdraw")
async def request_withdrawal(
    body: WithdrawalRequest,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    if body.amount < 100:
        raise HTTPException(status_code=400, detail="Minimum withdrawal amount is ₹100")

    wallet = await get_or_create_wallet(db, current_user.id)

    # Validate bank/UPI details exist
    if body.method == "bank":
        if not wallet.bank_account_number or not wallet.bank_ifsc:
            raise HTTPException(status_code=400, detail="Please add your bank details before withdrawing")
    elif body.method == "upi":
        if not wallet.upi_id:
            raise HTTPException(status_code=400, detail="Please add your UPI ID before withdrawing")
    else:
        raise HTTPException(status_code=400, detail="Invalid withdrawal method. Use 'bank' or 'upi'")

    txn = await debit_wallet(
        db,
        user_id=current_user.id,
        amount=Decimal(str(body.amount)),
        purpose=TransactionPurpose.withdrawal,
        description=f"Withdrawal via {body.method.upper()} — ₹{body.amount}",
    )

    return {
        "message": "Withdrawal request submitted. Funds will be transferred within 24-48 hours.",
        "transaction_id": str(txn.id),
        "amount": body.amount,
        "new_balance": float(wallet.balance),
    }
