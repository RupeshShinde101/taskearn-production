from decimal import Decimal
from typing import Optional
from uuid import UUID

from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from fastapi import HTTPException

from models.wallet import Wallet, Transaction, TransactionType, TransactionStatus, TransactionPurpose


async def get_or_create_wallet(db: AsyncSession, user_id: UUID) -> Wallet:
    result = await db.execute(select(Wallet).where(Wallet.user_id == user_id))
    wallet = result.scalar_one_or_none()
    if not wallet:
        wallet = Wallet(user_id=user_id, balance=Decimal("0.00"))
        db.add(wallet)
        await db.flush()
    return wallet


async def credit_wallet(
    db: AsyncSession,
    user_id: UUID,
    amount: Decimal,
    purpose: TransactionPurpose,
    task_id: Optional[UUID] = None,
    razorpay_payment_id: Optional[str] = None,
    razorpay_order_id: Optional[str] = None,
    description: Optional[str] = None,
) -> Transaction:
    wallet = await get_or_create_wallet(db, user_id)
    wallet.balance += amount

    if purpose == TransactionPurpose.task_earning:
        wallet.total_earned += amount
    elif purpose == TransactionPurpose.deposit:
        pass  # just balance update

    balance_after = wallet.balance

    txn = Transaction(
        wallet_id=wallet.id,
        user_id=user_id,
        type=TransactionType.credit,
        status=TransactionStatus.completed,
        purpose=purpose,
        amount=amount,
        balance_after=balance_after,
        task_id=task_id,
        razorpay_payment_id=razorpay_payment_id,
        razorpay_order_id=razorpay_order_id,
        description=description,
    )
    db.add(txn)
    await db.flush()
    return txn


async def debit_wallet(
    db: AsyncSession,
    user_id: UUID,
    amount: Decimal,
    purpose: TransactionPurpose,
    task_id: Optional[UUID] = None,
    razorpay_payment_id: Optional[str] = None,
    razorpay_order_id: Optional[str] = None,
    description: Optional[str] = None,
) -> Transaction:
    wallet = await get_or_create_wallet(db, user_id)

    if wallet.balance < amount:
        raise HTTPException(status_code=400, detail="Insufficient wallet balance")

    wallet.balance -= amount

    if purpose == TransactionPurpose.task_payment:
        wallet.total_spent += amount
    elif purpose == TransactionPurpose.withdrawal:
        wallet.total_withdrawn += amount

    balance_after = wallet.balance

    txn = Transaction(
        wallet_id=wallet.id,
        user_id=user_id,
        type=TransactionType.debit,
        status=TransactionStatus.completed,
        purpose=purpose,
        amount=amount,
        balance_after=balance_after,
        task_id=task_id,
        razorpay_payment_id=razorpay_payment_id,
        razorpay_order_id=razorpay_order_id,
        description=description,
    )
    db.add(txn)
    await db.flush()
    return txn
